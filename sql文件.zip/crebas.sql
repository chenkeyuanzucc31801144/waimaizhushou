/*==============================================================*/
/* DBMS name:      Sybase SQL Anywhere 11                       */
/* Created on:     2020/7/9 8:47:11                             */
/*==============================================================*/


if exists(
   select 1 from sys.systable 
   where table_name='dingdanxiangqing_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table dingdanxiangqing_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='guanliyuan_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table guanliyuan_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='haveyouhuiquan_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table haveyouhuiquan_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='jidansongquan_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table jidansongquan_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='manjianfangan_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table manjianfangan_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='peisongid_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table peisongid_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='qishou1_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table qishou1_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='qishou_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table qishou_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='qishouincome_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table qishouincome_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='shangjia1_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table shangjia1_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='shangjia_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table shangjia_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='shangpindingdan_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table shangpindingdan_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='shangpinleibie_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table shangpinleibie_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='shangpinpingjia_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table shangpinpingjia_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='shangpinxiangqing'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table shangpinxiangqing
end if;

if exists(
   select 1 from sys.systable 
   where table_name='yonghu1_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table yonghu1_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='yonghuinfo_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table yonghuinfo_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='youhuiquan_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table youhuiquan_info
end if;

/*==============================================================*/
/* Table: dingdanxiangqing_info                                 */
/*==============================================================*/
create table dingdanxiangqing_info 
(
   dingdanxiangqing_id  varchar(20)                    not null,
   shangpinxiangqing_id varchar(20)                    null,
   number_number        integer                        null,
   price_money          numeric(10,5)                  null,
   danpinyouhui_money   numeric(10,5)                  null
);

/*==============================================================*/
/* Table: guanliyuan_info                                       */
/*==============================================================*/
create table guanliyuan_info 
(
   yuangong_id          varchar(20)                    not null,
   yuandong_name        varchar(20)                    null,
   password_word        varchar(20)                    null
);

/*==============================================================*/
/* Table: haveyouhuiquan_info                                   */
/*==============================================================*/
create table haveyouhuiquan_info 
(
   yonghuyouhuiquan_id  varchar(20)                    not null,
   youhuiquan_id        varchar(20)                    null,
   suoshushangjia_id    varchar(20)                    null,
   youhui_money         numeric(10,2)                  null,
   number_number        integer                        null,
   deadline_date        date                           null
);

/*==============================================================*/
/* Table: jidansongquan_info                                    */
/*==============================================================*/
create table jidansongquan_info 
(
   yonghujidansonguqan_id varchar(20)                    not null,
   shangjia_id          varchar(20)                    null,
   youhuiquan_id        varchar(20)                    null,
   jidanyaoqiu_number   integer                        null,
   alreadydingdan_number integer                        null
);

/*==============================================================*/
/* Table: manjianfangan_info                                    */
/*==============================================================*/
create table manjianfangan_info 
(
   manjian_id           varchar(20)                    not null,
   manjian_money        numeric(10,5)                  null,
   youhui_money         numeric(10,2)                  null,
   youhuiquandiejia_yesorno smallint                       null
);

/*==============================================================*/
/* Table: peisongid_info                                        */
/*==============================================================*/
create table peisongid_info 
(
   dizhi_id             varchar(20)                    not null,
   yonghu_id            varchar(20)                    null,
   province_name        varchar(20)                    null,
   city_name            varchar(20)                    null,
   area_name            varchar(20)                    null,
   address_name         varchar(20)                    null,
   lianxiren_name       varchar(20)                    null,
   tel_number           varchar(20)                    null
);

/*==============================================================*/
/* Table: qishou1_info                                          */
/*==============================================================*/
create table qishou1_info 
(
   qishou1_info         char(10)                       null,
   qishoumoney1_info    char(10)                       null
);

/*==============================================================*/
/* Table: qishou_info                                           */
/*==============================================================*/
create table qishou_info 
(
   qishou_id            varchar(20)                    not null,
   qishou_name          varchar(20)                    null,
   ruzhi_date           date                           null,
   qishoushenfen_name   varchar(10)                    null
);

/*==============================================================*/
/* Table: qishouincome_info                                     */
/*==============================================================*/
create table qishouincome_info 
(
   qishouincome_id      varchar(20)                    not null,
   suojiedingdan_id     varchar(20)                    null,
   time_date            timestamp                      null,
   yonghupingjia_word   varchar(1000)                  null
);

/*==============================================================*/
/* Table: shangjia1_info                                        */
/*==============================================================*/
create table shangjia1_info 
(
   youhuiquan1_info     char(10)                       null,
   shangjia1_info       char(10)                       null,
   manjianfangan1_info  char(10)                       null,
   shangpinleibie1_info char(10)                       null,
   shangpinxiangqing1_info char(10)                       null,
   shangpingpinjia1_info char(10)                       null
);

/*==============================================================*/
/* Table: shangjia_info                                         */
/*==============================================================*/
create table shangjia_info 
(
   shangjia_id          varchar(20)                    not null,
   shangjia_name        varchar(20)                    null,
   shangjia_star        numeric(2,2)                   null,
   peopleavg_money      numeric(10,5)                  null,
   allselled_number     numeric(20,5)                  null
);

/*==============================================================*/
/* Table: shangpindingdan_info                                  */
/*==============================================================*/
create table shangpindingdan_info 
(
   dingdan_id           varchar(20)                    not null,
   shangjia_id          varchar(20)                    null,
   yonghu_id            varchar(20)                    null,
   qishou_id            varchar(20)                    null,
   originalamount_money numeric(10,5)                  null,
   settlementamount_money numeric(10,5)                  null,
   manjian_id           varchar(20)                    null,
   shiyongyouhuiquan_id varchar(20)                    null,
   xiadan_date          timestamp                      null,
   yaoqiusongda_date    timestamp                      null,
   qiesongdizhiid_name  varchar(20)                    null,
   dingdanzhuangtai_name varchar(10)                    null
);

/*==============================================================*/
/* Table: shangpinleibie_info                                   */
/*==============================================================*/
create table shangpinleibie_info 
(
   fenlei_id            varchar(20)                    not null,
   fenlei_name          varchar(20)                    null,
   shangping_number     integer                        null
);

/*==============================================================*/
/* Table: shangpinpingjia_info                                  */
/*==============================================================*/
create table shangpinpingjia_info 
(
   shangpinpingjia_id   varchar(20)                    not null,
   shangjia_id          varchar(20)                    null,
   yonghu_id            varchar(20)                    null,
   pingjia_word         varchar(1000)                  null,
   pingjia_date         timestamp                      null,
   pingjia_star         numeric(2,2)                   null,
   pingjia_photo        long binary                    null
);

/*==============================================================*/
/* Table: shangpinxiangqing                                     */
/*==============================================================*/
create table shangpinxiangqing 
(
   shangpinxiangqing_id varchar(20)                    not null,
   suoshufenlei_id      varchar(20)                    null,
   shangpin_name        varchar(20)                    null,
   price_money          numeric(10,5)                  null,
   priceoff_money       numeric(10,5)                  null
);

/*==============================================================*/
/* Table: yonghu1_info                                          */
/*==============================================================*/
create table yonghu1_info 
(
   yonghuinfo1_info     char(10)                       null,
   haveyouhuiquan1_info char(10)                       null,
   jidansongquan1_info  char(10)                       null,
   peisongid1_info      char(10)                       null,
   shangpindingdan1_info char(10)                       null,
   dinganxiangqing1_info char(10)                       null
);

/*==============================================================*/
/* Table: yonghuinfo_info                                       */
/*==============================================================*/
create table yonghuinfo_info 
(
   yonghu_id            varchar(20)                    not null,
   name_name            varchar(20)                    null,
   sex_name             smallint                       null,
   password_word        varchar(20)                    null,
   phonenumber_word     varchar(20)                    null,
   mail_word            varchar(50)                    null,
   city_name            varchar(20)                    null,
   zhucetime_date       date                           null,
   huiyuan_yesorno      smallint                       null,
   huiyuandeadline_date date                           null
);

/*==============================================================*/
/* Table: youhuiquan_info                                       */
/*==============================================================*/
create table youhuiquan_info 
(
   youhuiquan_id        varchar(20)                    not null,
   youhui_money         numeric(10,2)                  null,
   jidanyaoqiu_number   integer                        null,
   start_date           date                           null,
   final_date           date                           null
);

