package cn.edu.zucc.takeaway.assistant.itf;

public class IAdminManager {

}
