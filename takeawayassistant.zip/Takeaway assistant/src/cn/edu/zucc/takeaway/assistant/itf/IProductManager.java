package cn.edu.zucc.takeaway.assistant.itf;

public class IProductManager {

}
