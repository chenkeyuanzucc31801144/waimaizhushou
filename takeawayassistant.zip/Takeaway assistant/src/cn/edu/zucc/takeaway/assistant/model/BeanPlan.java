package cn.edu.zucc.takeaway.assistant.model;

public class BeanPlan {

}
