package cn.edu.zucc.takeaway.assistant.control;

public class ProductManager {

}
