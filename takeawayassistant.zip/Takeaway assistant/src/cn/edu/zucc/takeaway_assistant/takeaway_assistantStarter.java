package cn.edu.zucc.takeaway_assistant;
import cn.edu.zucc.takeaway_assistant.ui.FrmMain;

public class takeaway_assistantStarter {
	public static void main() {
			new FrmMain();
		}
	
}
