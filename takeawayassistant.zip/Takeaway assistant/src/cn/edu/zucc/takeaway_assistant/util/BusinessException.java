package cn.edu.zucc.takeaway_assistant.util;

public class BusinessException  extends BaseException {
	public BusinessException(String msg){
		super(msg);
	}
}

