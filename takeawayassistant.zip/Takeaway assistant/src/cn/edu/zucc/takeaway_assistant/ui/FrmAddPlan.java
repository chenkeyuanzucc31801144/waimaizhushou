package cn.edu.zucc.takeaway_assistant.ui;

public class FrmAddPlan {

}
