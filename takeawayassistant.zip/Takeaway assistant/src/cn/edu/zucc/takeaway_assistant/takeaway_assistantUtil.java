package cn.edu.zucc.takeaway_assistant;
import cn.edu.zucc.takeaway.assistant.control.AddressManager;
import cn.edu.zucc.takeaway.assistant.control.ProductManager;
import cn.edu.zucc.takeaway.assistant.control.UserManager;
import cn.edu.zucc.takeaway.assistant.itf.IProductManager;
import cn.edu.zucc.takeaway.assistant.itf.IUserManager;
import cn.edu.zucc.takeaway.assistant.itf.IaddressManager;

public class takeaway_assistantUtil {
	
	
}
